import React from 'react';
import { Dropdown } from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import './styles/NavbarSearchStyle.css'; // Verifique o caminho do arquivo de estilos
import roomtype from '../images/roomtype.png'; // Verifique o caminho da imagem
import person from '../images/person.png'; // Verifique o caminho da imagem

function NavbarSearch() {
  return (
    <div className="div">
      <div className="div-2">
        <img
          loading="lazy"
          src={roomtype}
          className="img"
          alt="Room Type Icon"
        />
        <div className="div-3">
          <div className="div-4">Room type</div>
          <div className="div-5">
            <Dropdown>
              <Dropdown.Toggle variant="success" id="dropdown-roomtype">
                Selection
              </Dropdown.Toggle>

              <Dropdown.Menu>
                <Dropdown.Item href="#/action-1">SINGLE ROOM</Dropdown.Item>
                <Dropdown.Item href="#/action-2">DOUBLE ROOM</Dropdown.Item>
                <Dropdown.Item href="#/action-3">SUITE ROOM</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>
        <img
          loading="lazy"
          src={person}
          className="img-3"
          alt="Person Icon"
        />
        <div className="div-7">
          <div className="div-8">Person</div>
          <div className="div-9">
            <Dropdown>
              <Dropdown.Toggle variant="success" id="dropdown-person">
                Selection
              </Dropdown.Toggle>

              <Dropdown.Menu>
                <Dropdown.Item href="#/action-1">1 Person</Dropdown.Item>
                <Dropdown.Item href="#/action-2">2 People</Dropdown.Item>
                <Dropdown.Item href="#/action-3">3 People</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>
      </div>
      <div className="div-11">
        <div className="div-12">Check in</div>
        <div className="div-13">
          <DatePicker selected={new Date()} />
        </div>
      </div>
      <div className="div-14">
        <div className="div-15">Check out</div>
        <div className="div-16">
          <DatePicker selected={new Date()} />
        </div>
      </div>
      <div className="div-17">Book Now</div>
    </div>
  );
}

export default NavbarSearch;
