import React from "react";
import "./styles/FacilitiesStyle.css";
import swimming from "../images/swimming.png"
import wifi from "../images/wifi.png"
import breakfast from "../images/breakfast.png"
import gym from "../images/gym.png"
import game from "../images/game.png"
import light from "../images/light.png"
import laundry from "../images/laundry.png"
import parking from "../images/parking.png"



function Facilities() {
    return (
     
          <div className="container">
            <div className="title">Our Facilities</div>
            <div className="subtitle">We offer modern (5 star) hotel facilities for your comfort.</div>
            <div className="facility-container">
              <div className="facility">
                <div className="image-container">
                  <img
                    loading="lazy"
                    src={swimming}
                    alt="Swimming Pool"
                    className="image"
                  />
                </div>
                <div className="facility-title">Swimming Pool</div>
              </div>
              <div className="facility">
                <div className="image-container">
                  <img
                    loading="lazy"
                    src={wifi}
                    alt="Wifi"
                    className="image"
                  />
                </div>
                <div className="facility-title">Wifi</div>
              </div>
              <div className="facility">
                <div className="image-container">
                  <img
                    loading="lazy"
                    src={breakfast}
                    alt="Breakfast"
                    className="image"
                  />
                </div>
                <div className="facility-title">Breakfast</div>
              </div>
              <div className="facility">
                <div className="image-container">
                  <img
                    loading="lazy"
                    src={gym}
                    alt="Gym"
                    className="image"
                  />
                </div>
                <div className="facility-title">Gym</div>
              </div>
            </div>
            <div className="facility-container">
              <div className="facility">
                <div className="image-container">
                  <img
                    loading="lazy"
                    src={game}
                    alt="Game center"
                    className="image"
                  />
                </div>
                <div className="facility-title">Game center</div>
              </div>
              <div className="facility">
                <div className="image-container">
                  <img
                    loading="lazy"
                    src={light}
                    alt="24/7 Light"
                    className="image"
                  />
                </div>
                <div className="facility-title">24/7 Light</div>
              </div>
              <div className="facility">
                <div className="image-container">
                  <img
                    loading="lazy"
                    src={laundry}
                    alt="Laundry"
                    className="image"
                  />
                </div>
                <div className="facility-title">Laundry</div>
              </div>
              <div className="facility">
                <div className="image-container">
                  <img
                    loading="lazy"
                    src={parking}
                    alt="Parking space"
                    className="image"
                  />
                </div>
                <div className="facility-title">Parking space</div>
              </div>
            </div>
          </div>
        );
      }
      
      export default Facilities;
      