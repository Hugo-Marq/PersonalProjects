import React from 'react';
import headerimage from '../images/header_homepage_image.png';
import './styles/HeaderHomepageStyle.css';






function HeaderHomepage() {
  return (
    
      <div className="HeaderHomepage">
         <div className="div-2">
          <div className="column">
            <div className="div-3">
              <div className="div-4">QuickRoom Solution</div>
              <div className="div-5">
                Hotel for every <br />
                moment rich in
                <br />
                emotion
              </div>
              <div className="div-6">
                Every moment feels like the first time
                <br />
                in paradise view
              </div>
            </div>
          </div>
          <div className="column-2">
            <img
              loading="lazy"
              src={headerimage}
              className="img"
            />
          </div>
        </div>
      </div>
  
  );
}

export default HeaderHomepage;






  
  