// Footer.js

import React from 'react';
import './styles/FooterStyle.css'; // Importe o arquivo de estilos


function Footer() {
    return (
      <div className="FooterContainer">
        <div className="MainElementsContainer">
          {/* Company Info */}
          <div className="Column">
            <div className="Title">QuickRoom Solution</div>
            <div className="CompanyInfo">
              The service at the Hotel Monteleone was exceptional. There was absolutely no issue that was not addressed timely and with satisfactory results. We were particularly impressed with how the hotel staff anticipated our needs (periodically coming by the Board Room to check with us).
            </div>
          </div>
  
          {/* Company Links */}
          <div className="Column">
            <div className="Title">Company</div>
            <div className="CompanyLinks">
              <ul>
                <li>Privacy policy</li>
                <li>Refund policy</li>
                <li>F.A.Q</li>
              </ul>
            </div>
          </div>
  
          {/* Social Media */}
          <div className="Column">
            <div className="Title">Social Media</div>
            <div className="SocialMedia">
              <ul>
                <li>Facebook</li>
                <li>Instagram</li>
                <li>LinkedIn</li>
                <li>Twitter</li>
              </ul>
            </div>
          </div>
        </div>
  
        {/* Newsletter Container */}
        <div className="NewsletterContainer">
          <div className="NewsletterTitle">Newsletter Sign Up</div>
          <div className="FormContainer">
            <input
              type="text"
              placeholder="Enter your email here...."
              className="EmailInput"
            />
            <button className="SubmitButton">Submit</button>
          </div>
        </div>
  
        {/* Footer Info */}
        <div className="FooterInfo">QuickRoom Solution 2024.</div>
      </div>
    );
  }
  
  export default Footer;
  