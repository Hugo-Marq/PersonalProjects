import { useState } from 'react'; // Importe useState ao invés de React
import './styles/NavbarStyle.css'; // Importe o arquivo de estilos
import logoImg from '../images/logo.png';


function Navbar() {
  
const [selectedItem, setSelectedItem] = useState(null);

const handleItemClick = (item) => {
  setSelectedItem(item);
};


 return (
    <div className="navbar-container">
      <img
        loading="lazy"
        src={logoImg}
        className="logo"
        alt="Company Logo"
      />
      <div className="menu-items">
        <div
          className={`menu-item ${selectedItem === 'home' ? 'selected' : ''}`}
          onClick={() => handleItemClick('home')}
        >
          Home
        </div>
        <div
          className={`menu-item ${selectedItem === 'explore' ? 'selected' : ''}`}
          onClick={() => handleItemClick('explore')}
        >
          Explore
        </div>
        <div
          className={`menu-item ${selectedItem === 'rooms' ? 'selected' : ''}`}
          onClick={() => handleItemClick('rooms')}
        >
          Rooms
        </div>
        <div
          className={`menu-item ${selectedItem === 'about' ? 'selected' : ''}`}
          onClick={() => handleItemClick('about')}
        >
          About
        </div>
        <div
          className={`menu-item ${selectedItem === 'contacts' ? 'selected' : ''}`}
          onClick={() => handleItemClick('contacts')}
        >
          Contacts
        </div>
      </div>
      <div className="login-button">Login</div>
    </div>
  );
}

export default Navbar;