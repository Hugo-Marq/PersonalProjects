import React from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer'; // Importe o componente Footer
import './App.css'; // Importe os estilos globais
import HeaderHomepage from './components/HeaderHomepage';
import './components/styles/HeaderHomepageStyle.css'; // Importe os estilos do HeaderHomepage
import Facilities from './components/Facilities'; // Importe o componente Facilities
import './components/styles/FacilitiesStyle.css'; // Importe os estilos do Facilities*/
import './components/styles/FooterStyle.css'; // Importe os estilos do Footer
import './components/styles/NavbarStyle.css'; // Importe os estilos do Navbar
import './components/styles/NavbarSearchStyle.css'; // Importe os estilos do NavbarSearch
import NavbarSearch from './components/NavbarSearch'; // Importe o componente NavbarSearch

function App() {
  return (
    <div className="App">
    <header>
      <Navbar />
    </header>
    <main>
    <HeaderHomepage className="HeaderHomepage" />
    <NavbarSearch className="NavbarSearch" />
      <Facilities className="Facilities" />
    </main>
    <footer>
      <Footer />
    </footer>
  </div>
);
}


export default App;

